package org.example.okta;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.concurrent.Executors;

import com.sun.net.httpserver.HttpServer;

public class OktaAuthServicePKCE {

    private static final OkHttpClient client = new OkHttpClient();
    private static final ObjectMapper mapper = new ObjectMapper();

    public interface AuthCallback {
        void onSuccess(String accessToken, String idToken);
        void onError(String message);
    }

    public static void authenticate(AuthCallback callback) {
        new Thread(() -> {
            try {
                // 1. Generate PKCE code_verifier & code_challenge
                String codeVerifier = generateCodeVerifier();
                String codeChallenge = generateCodeChallenge(codeVerifier);

                // 2. Start local HTTP server for redirect_uri
                int port = 49152 + new SecureRandom().nextInt(1000);
                String redirectUri = "http://127.0.0.1:" + port + "/callback";

                final StringBuilder authCodeHolder = new StringBuilder();
                HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
                server.createContext("/callback", exchange -> {
                    String query = exchange.getRequestURI().getQuery();
                    if (query != null && query.contains("code=")) {
                        String code = query.split("code=")[1].split("&")[0];
                        authCodeHolder.append(code);
                        String resp = "<html><body><h2>Login successful! You may close this window.</h2></body></html>";
                        exchange.sendResponseHeaders(200, resp.length());
                        exchange.getResponseBody().write(resp.getBytes());
                        exchange.close();
                        server.stop(1);
                    }
                });
                server.setExecutor(Executors.newSingleThreadExecutor());
                server.start();

                // 3. Build authorize URL
                String authUrl = OktaConfig.OKTA_DOMAIN + "/v1/authorize" +
                        "?client_id=" + OktaConfig.CLIENT_ID +
                        "&response_type=code" +
                        "&scope=" + OktaConfig.SCOPE +
                        "&redirect_uri=" + redirectUri +
                        "&code_challenge=" + codeChallenge +
                        "&code_challenge_method=S256" +
                        "&state=xyz";

                // Open browser
                Desktop.getDesktop().browse(URI.create(authUrl));

                // 4. Wait for authorization code
                while (authCodeHolder.length() == 0) {
                    Thread.sleep(500);
                }
                String authCode = authCodeHolder.toString();

                // 5. Exchange code for tokens
                RequestBody tokenBody = new FormBody.Builder()
                        .add("grant_type", "authorization_code")
                        .add("client_id", OktaConfig.CLIENT_ID)
                        .add("redirect_uri", redirectUri)
                        .add("code", authCode)
                        .add("code_verifier", codeVerifier)
                        .build();

                Request tokenRequest = new Request.Builder()
                        .url(OktaConfig.OKTA_DOMAIN + "/v1/token")
                        .post(tokenBody)
                        .header("Accept", "application/json")
                        .build();

                Response tokenResponse = client.newCall(tokenRequest).execute();
                String tokenRespStr = tokenResponse.body().string();

                if (tokenResponse.isSuccessful()) {
                    JsonNode tokenJson = mapper.readTree(tokenRespStr);
                    String accessToken = tokenJson.get("access_token").asText();
                    String idToken = tokenJson.get("id_token").asText();
                    callback.onSuccess(accessToken, idToken);
                } else {
                    JsonNode errorResp = mapper.readTree(tokenRespStr);
                    String error = errorResp.has("error") ? errorResp.get("error").asText() : "unknown_error";
                    callback.onError("Okta Auth Failed: " + error);
                }

            } catch (Exception e) {
                callback.onError("Exception: " + e.getMessage());
            }
        }).start();
    }

    // --- Helpers ---
    private static String generateCodeVerifier() {
        byte[] code = new byte[32];
        new SecureRandom().nextBytes(code);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(code);
    }

    private static String generateCodeChallenge(String codeVerifier) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(codeVerifier.getBytes());
        return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
    }
}
