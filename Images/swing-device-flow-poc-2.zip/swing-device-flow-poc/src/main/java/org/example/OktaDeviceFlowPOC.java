package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class OktaDeviceFlowPOC {

    // Replace with your Okta details
    private static final String OKTA_DOMAIN = "https://YOUR_OKTA_DOMAIN.okta.com";
    private static final String CLIENT_ID = "YOUR_CLIENT_ID";
    private static final String SCOPE = "openid profile offline_access";

    private static final OkHttpClient client = new OkHttpClient();
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void main(String[] args) throws Exception {
        // Step 1: Request device code
        RequestBody body = new FormBody.Builder()
                .add("client_id", CLIENT_ID)
                .add("scope", SCOPE)
                .build();

        Request request = new Request.Builder()
                .url(OKTA_DOMAIN + "/oauth2/v1/device/authorize")
                .post(body)
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

        JsonNode deviceResponse = mapper.readTree(response.body().string());
        String deviceCode = deviceResponse.get("device_code").asText();
        String userCode = deviceResponse.get("user_code").asText();
        String verificationUri = deviceResponse.get("verification_uri").asText();
        String verificationUriComplete = deviceResponse.get("verification_uri_complete").asText();
        int interval = deviceResponse.get("interval").asInt();

        System.out.println("==== Device Authorization ====");
        System.out.println("Go to this URL: " + verificationUri);
        System.out.println("Enter the User Code: " + userCode);
        System.out.println("Or directly open: " + verificationUriComplete);

        // Step 2: Poll token endpoint
        while (true) {
            RequestBody tokenBody = new FormBody.Builder()
                    .add("client_id", CLIENT_ID)
                    .add("device_code", deviceCode)
                    .add("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                    .build();

            Request tokenRequest = new Request.Builder()
                    .url(OKTA_DOMAIN + "/oauth2/v1/token")
                    .post(tokenBody)
                    .header("Accept", "application/json")
                    .build();

            Response tokenResponse = client.newCall(tokenRequest).execute();
            String tokenRespStr = tokenResponse.body().string();

            if (tokenResponse.isSuccessful()) {
                JsonNode tokenJson = mapper.readTree(tokenRespStr);
                String accessToken = tokenJson.get("access_token").asText();
                String idToken = tokenJson.get("id_token").asText();
                System.out.println("✅ Login Successful!");
                System.out.println("Access Token: " + accessToken);
                System.out.println("ID Token: " + idToken);
                break;
            } else {
                JsonNode errorResp = mapper.readTree(tokenRespStr);
                String error = errorResp.has("error") ? errorResp.get("error").asText() : "unknown_error";
                if ("authorization_pending".equals(error)) {
                    System.out.println("Waiting for user to complete login...");
                    TimeUnit.SECONDS.sleep(interval);
                } else {
                    System.out.println("❌ Error: " + error);
                    break;
                }
            }
        }
    }
}
