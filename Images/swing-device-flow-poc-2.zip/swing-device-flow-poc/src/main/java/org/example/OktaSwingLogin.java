//package org.example;
//
//import javax.swing.*;
//import java.awt.*;
//import java.io.IOException;
//import java.io.OutputStream;
//import java.net.*;
//import java.net.http.HttpClient;
//import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
//import java.security.MessageDigest;
//import java.security.SecureRandom;
//import java.util.Base64;
//
//import java.net.http.HttpClient;
//
//import com.sun.net.httpserver.HttpServer;
//
//import com.fasterxml.jackson.databind.JsonNode;
//
//public class OktaSwingLogin {
//
//    // TODO: Replace with your Okta app settings
//    private static final String ISSUER = "https://dev-08094251.okta.com/oauth2/default";
//    private static final String CLIENT_ID = "0oaq0kywq9A86Thi35d7";
//    private static final String REDIRECT_URI = "http://127.0.0.1:8080/callback";
//    private static final String SCOPES = "openid profile offline_access";
//
//    private static String codeVerifier;
//
//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(OktaSwingLogin::createUI);
//    }
//
//    private static void createUI() {
//        JFrame frame = new JFrame("Okta Login");
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.setSize(300, 200);
//
//        JButton loginButton = new JButton("Login with Okta");
//        loginButton.addActionListener(e -> {
//            try {
//                startLoginFlow();
//            } catch (Exception ex) {
//                ex.printStackTrace();
//            }
//        });
//
//        frame.getContentPane().setLayout(new GridBagLayout());
//        frame.getContentPane().add(loginButton);
//        frame.setVisible(true);
//    }
//
//    private static void startLoginFlow() throws Exception {
//        // Generate PKCE
//        codeVerifier = generateCodeVerifier();
//        String codeChallenge = generateCodeChallenge(codeVerifier);
//
//        // Build authorization URL
//        String authUrl = String.format(
//                "%s/v1/authorize?client_id=%s&response_type=code&scope=%s&redirect_uri=%s&state=12345&code_challenge=%s&code_challenge_method=S256",
//                ISSUER, CLIENT_ID,
//                URLEncoder.encode(SCOPES, "UTF-8"),
//                URLEncoder.encode(REDIRECT_URI, "UTF-8"),
//                codeChallenge);
//
//        // Start callback listener
//        startHttpCallbackServer();
//
//        // Open browser
//        Desktop.getDesktop().browse(new URI(authUrl));
//    }
//
//    private static void startHttpCallbackServer() throws IOException {
//        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
//        server.createContext("/callback", exchange -> {
//            String query = exchange.getRequestURI().getQuery();
//            String code = null;
//            if (query != null && query.contains("code=")) {
//                code = query.split("code=")[1].split("&")[0];
//            }
//
//            String response = "Login successful! You may close this window.";
//            exchange.sendResponseHeaders(200, response.getBytes().length);
//            try (OutputStream os = exchange.getResponseBody()) {
//                os.write(response.getBytes());
//            }
//
//            if (code != null) {
//                try {
//                    exchangeCodeForTokens(code);
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//            server.stop(1);
//        });
//        server.start();
//    }
//
//    private static void exchangeCodeForTokens(String code) throws Exception {
//        String tokenUrl = ISSUER + "/v1/token";
//
//        String body = "grant_type=authorization_code" +
//                "&code=" + code +
//                "&redirect_uri=" + URLEncoder.encode(REDIRECT_URI, "UTF-8") +
//                "&client_id=" + CLIENT_ID +
//                "&code_verifier=" + codeVerifier;
//
//        HttpRequest request = HttpRequest.newBuilder()
//                .uri(URI.create(tokenUrl))
//                .header("Content-Type", "application/x-www-form-urlencoded")
//                .POST(HttpRequest.BodyPublishers.ofString(body))
//                .build();
//
//        HttpClient client = HttpClient.newHttpClient();
//        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//
//        JOptionPane.showMessageDialog(null, "Tokens: " + response.body());
//    }
//
//    // PKCE Helpers
//    private static String generateCodeVerifier() {
//        byte[] code = new byte[32];
//        new SecureRandom().nextBytes(code);
//        return Base64.getUrlEncoder().withoutPadding().encodeToString(code);
//    }
//
//    private static String generateCodeChallenge(String codeVerifier) throws Exception {
//        MessageDigest md = MessageDigest.getInstance("SHA-256");
//        byte[] digest = md.digest(codeVerifier.getBytes());
//        return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
//    }
//}
