package org.example.okta;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Base64;

public class JwtUtils {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static JsonNode decodeJWT(String jwt) throws Exception {
        String[] parts = jwt.split("\\.");
        if (parts.length < 2) throw new IllegalArgumentException("Invalid JWT format");

        String payload = new String(Base64.getUrlDecoder().decode(parts[1]));
        return mapper.readTree(payload);
    }

    public static String prettyPrint(JsonNode node) throws Exception {
        return mapper.writerWithDefaultPrettyPrinter().writeValueAsString(node);
    }
}
