package org.example;

import com.sun.net.httpserver.HttpServer;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;

public class OktaPKCESample {
    private static final String CLIENT_ID = "0oaq0kywq9A86Thi35d7";
    private static final String ISSUER = "https://dev-08094251.okta.com/oauth2/default";
    private static final String REDIRECT_URI = "http://127.0.0.1:8080/callback";

    public static void main(String[] args) throws Exception {
        // 1. Generate PKCE
        String codeVerifier = generateCodeVerifier();
        String codeChallenge = generateCodeChallenge(codeVerifier);

        // 2. Start local HTTP server
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);
        final String[] authCodeHolder = new String[1];

        server.createContext("/callback", exchange -> {
            String query = exchange.getRequestURI().getQuery();
            String code = Arrays.stream(query.split("&"))
                    .filter(q -> q.startsWith("code="))
                    .map(q -> q.split("=")[1])
                    .findFirst().orElse(null);

            String response = "You may now close this window.";
            exchange.sendResponseHeaders(200, response.getBytes().length);
            exchange.getResponseBody().write(response.getBytes());
            exchange.close();

            authCodeHolder[0] = code;
            System.out.println("Authorization Code received: " + code);
        });
        server.start();

        // 3. Open browser for login
        String scopes = "openid%20profile%20offline_access";

        String authUrl = String.format(
                "%s/v1/authorize?client_id=%s&response_type=code&scope=%s&redirect_uri=%s&state=12345&code_challenge=%s&code_challenge_method=S256",
                ISSUER, CLIENT_ID, scopes, URLEncoder.encode(REDIRECT_URI, "UTF-8"), codeChallenge);
        Desktop.getDesktop().browse(new URI(authUrl));

        // 4. Wait for auth code
        while (authCodeHolder[0] == null) {
            Thread.sleep(500);
        }
        server.stop(0);

        // 5. Exchange code for tokens
        String tokenEndpoint = ISSUER + "/v1/token";
        String params = "grant_type=authorization_code"
                + "&code=" + authCodeHolder[0]
                + "&redirect_uri=" + URLEncoder.encode(REDIRECT_URI, "UTF-8")
                + "&client_id=" + CLIENT_ID
                + "&code_verifier=" + codeVerifier;

        HttpURLConnection conn = (HttpURLConnection) new URL(tokenEndpoint).openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        try (OutputStream os = conn.getOutputStream()) {
            os.write(params.getBytes(StandardCharsets.UTF_8));
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line; StringBuilder sb = new StringBuilder();
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();

        System.out.println("Token Response: " + sb.toString());
    }

    // PKCE helpers
    private static String generateCodeVerifier() {
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private static String generateCodeChallenge(String verifier) throws Exception {
        byte[] bytes = verifier.getBytes(StandardCharsets.US_ASCII);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] digest = md.digest(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(digest);
    }
}
