package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class OktaDeviceFlowSwing {

    // Replace with your Okta details
    private static final String OKTA_DOMAIN = "https://dev-08094251.okta.com/";
    private static final String CLIENT_ID = "0oaq0kywq9A86Thi35d7";
    private static final String SCOPE = "openid profile offline_access";

    private static final OkHttpClient client = new OkHttpClient();
    private static final ObjectMapper mapper = new ObjectMapper();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Okta Device Flow POC");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(600, 400);

            JTextArea outputArea = new JTextArea();
            outputArea.setEditable(false);
            JScrollPane scrollPane = new JScrollPane(outputArea);

            JButton startButton = new JButton("Start Authentication");

            startButton.addActionListener(e -> new Thread(() -> {
                try {
                    authenticate(outputArea);
                } catch (Exception ex) {
                    appendText(outputArea, "❌ Error: " + ex.getMessage());
                }
            }).start());

            frame.add(scrollPane, BorderLayout.CENTER);
            frame.add(startButton, BorderLayout.SOUTH);

            frame.setVisible(true);
        });
    }

    private static void authenticate(JTextArea outputArea) throws Exception {
        // Step 1: Request device code
        RequestBody body = new FormBody.Builder()
                .add("client_id", CLIENT_ID)
                .add("scope", SCOPE)
                .build();

        Request request = new Request.Builder()
                .url(OKTA_DOMAIN + "/oauth2/v1/device/authorize")
                .post(body)
                .build();

        Response response = client.newCall(request).execute();
        if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

        JsonNode deviceResponse = mapper.readTree(response.body().string());
        String deviceCode = deviceResponse.get("device_code").asText();
        String userCode = deviceResponse.get("user_code").asText();
        String verificationUri = deviceResponse.get("verification_uri").asText();
        String verificationUriComplete = deviceResponse.get("verification_uri_complete").asText();
        int interval = deviceResponse.get("interval").asInt();

        appendText(outputArea, "==== Device Authorization ====\n");
        appendText(outputArea, "Go to this URL: " + verificationUri + "\n");
        appendText(outputArea, "Enter the User Code: " + userCode + "\n");
        appendText(outputArea, "Or directly open: " + verificationUriComplete + "\n");

        // Step 2: Poll token endpoint
        while (true) {
            RequestBody tokenBody = new FormBody.Builder()
                    .add("client_id", CLIENT_ID)
                    .add("device_code", deviceCode)
                    .add("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                    .build();

            Request tokenRequest = new Request.Builder()
                    .url(OKTA_DOMAIN + "/oauth2/v1/token")
                    .post(tokenBody)
                    .header("Accept", "application/json")
                    .build();

            Response tokenResponse = client.newCall(tokenRequest).execute();
            String tokenRespStr = tokenResponse.body().string();

            if (tokenResponse.isSuccessful()) {
                JsonNode tokenJson = mapper.readTree(tokenRespStr);
                String accessToken = tokenJson.get("access_token").asText();
                String idToken = tokenJson.get("id_token").asText();
                appendText(outputArea, "✅ Login Successful!\n");
                appendText(outputArea, "Access Token: " + accessToken + "\n");
                appendText(outputArea, "ID Token: " + idToken + "\n");
                break;
            } else {
                JsonNode errorResp = mapper.readTree(tokenRespStr);
                String error = errorResp.has("error") ? errorResp.get("error").asText() : "unknown_error";
                if ("authorization_pending".equals(error)) {
                    appendText(outputArea, "Waiting for user to complete login...\n");
                    TimeUnit.SECONDS.sleep(interval);
                } else {
                    appendText(outputArea, "❌ Error: " + error + "\n");
                    break;
                }
            }
        }
    }

    private static void appendText(JTextArea area, String text) {
        SwingUtilities.invokeLater(() -> area.append(text + "\n"));
    }
}
