package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import org.example.okta.JwtUtils;

import org.example.okta.OktaAuthServicePKCE;   // Okta integration

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;

public class SimpleLoginAppWithOktaPKCE extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;

    // Login Page Components
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton oktaLoginButton;

    // Welcome Page Components
    private JLabel welcomeLabel;
    private JButton logoutButton;

    // Hardcoded credentials
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password";

    public SimpleLoginAppWithOktaPKCE() {
        setTitle("Simple Login App (PKCE)");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        JPanel loginPanel = createLoginPage();
        JPanel welcomePanel = createWelcomePage();

        mainPanel.add(loginPanel, "Login");
        mainPanel.add(welcomePanel, "Welcome");

        add(mainPanel);
        cardLayout.show(mainPanel, "Login");
    }

    private JPanel createLoginPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255));
        panel.setBorder(new EmptyBorder(50, 50, 50, 50));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel loginTitle = new JLabel("User Login", SwingConstants.CENTER);
        loginTitle.setFont(new Font("Arial", Font.BOLD, 24));
        loginTitle.setForeground(new Color(51, 51, 51));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(loginTitle, gbc);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(usernameLabel, gbc);

        usernameField = new JTextField(15);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(usernameField, gbc);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(passwordField, gbc);

        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(60, 179, 113));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(34, 139, 34), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        JLabel orLabel = new JLabel("OR", SwingConstants.CENTER);
        orLabel.setFont(new Font("Arial", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        panel.add(orLabel, gbc);

        oktaLoginButton = new JButton("Login with Okta (PKCE)");
        oktaLoginButton.setFont(new Font("Arial", Font.BOLD, 14));
        oktaLoginButton.setBackground(new Color(30, 144, 255));
        oktaLoginButton.setForeground(Color.WHITE);
        oktaLoginButton.setFocusPainted(false);
        oktaLoginButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(25, 25, 112), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        panel.add(oktaLoginButton, gbc);

        // Local login action
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (username.equals(USERNAME) && password.equals(PASSWORD)) {
                    welcomeLabel.setText("Welcome " + USERNAME + "!");
                    cardLayout.show(mainPanel, "Welcome");
                } else {
                    JOptionPane.showMessageDialog(SimpleLoginAppWithOktaPKCE.this,
                            "Invalid username or password.",
                            "Login Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Okta PKCE login action
        oktaLoginButton.addActionListener(e -> {
            OktaAuthServicePKCE.authenticate(new OktaAuthServicePKCE.AuthCallback() {
                @Override
                public void onSuccess(String accessToken, String idToken) {
                    SwingUtilities.invokeLater(() -> {
                        try {
                            JsonNode idClaims = JwtUtils.decodeJWT(idToken);
                            JsonNode accessClaims = JwtUtils.decodeJWT(accessToken);

                            String username = idClaims.has("preferred_username") ? idClaims.get("preferred_username").asText()
                                    : idClaims.has("email") ? idClaims.get("email").asText()
                                    : "Okta User";

                            welcomeLabel.setText("Welcome " + username + "!");

                            JTextArea detailsArea = new JTextArea();
                            detailsArea.setEditable(false);
                            detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

                            StringBuilder sb = new StringBuilder();
                            sb.append("=== ID TOKEN (claims) ===\n")
                                    .append(JwtUtils.prettyPrint(idClaims))
                                    .append("\n\n");
                            sb.append("=== ACCESS TOKEN (claims) ===\n")
                                    .append(JwtUtils.prettyPrint(accessClaims))
                                    .append("\n\n");
                            sb.append("=== RAW TOKENS ===\n")
                                    .append("Access Token:\n").append(accessToken).append("\n\n")
                                    .append("ID Token:\n").append(idToken).append("\n");

                            detailsArea.setText(sb.toString());
                            JScrollPane scrollPane = new JScrollPane(detailsArea);
                            scrollPane.setPreferredSize(new Dimension(700, 400));

                            JPanel welcomePanel = (JPanel) mainPanel.getComponent(1);
                            welcomePanel.add(scrollPane, BorderLayout.CENTER);
                            welcomePanel.revalidate();
                            welcomePanel.repaint();
                            cardLayout.show(mainPanel, "Welcome");
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(SimpleLoginAppWithOktaPKCE.this,
                                    "Failed to parse tokens: " + ex.getMessage(),
                                    "Token Error", JOptionPane.ERROR_MESSAGE);
                        }
                    });
                }

                @Override
                public void onError(String message) {
                    SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(SimpleLoginAppWithOktaPKCE.this,
                            "Okta login failed: " + message,
                            "Login Error", JOptionPane.ERROR_MESSAGE));
                }
            });
        });

        return panel;
    }

    private JPanel createWelcomePage() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(224, 255, 255));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        welcomeLabel = new JLabel("Welcome!", SwingConstants.LEFT);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 28));
        welcomeLabel.setForeground(new Color(0, 128, 128));
        topPanel.add(welcomeLabel, BorderLayout.WEST);

        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(255, 99, 71));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(205, 92, 92), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        topPanel.add(logoutButton, BorderLayout.EAST);

        panel.add(topPanel, BorderLayout.NORTH);

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                usernameField.setText("");
                passwordField.setText("");
                cardLayout.show(mainPanel, "Login");
            }
        });

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SimpleLoginAppWithOktaPKCE().setVisible(true));
    }
}
