package org.example.okta;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import java.awt.Desktop;
import java.io.IOException;
import java.io.OutputStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.UUID;

import com.sun.net.httpserver.HttpServer;

public class OktaAuthServicePKCE {
    private static final OkHttpClient client = new OkHttpClient();
    private static final ObjectMapper mapper = new ObjectMapper();

    public interface AuthCallback {
        void onSuccess(String accessToken, String idToken);
        void onError(String message);
    }

    public static void authenticate(AuthCallback callback) {
        new Thread(() -> {
            try {
                // ===== Step 1: Generate PKCE values =====
                String codeVerifier = generateCodeVerifier();
                String codeChallenge = generateCodeChallenge(codeVerifier);
                String state = UUID.randomUUID().toString(); // state parameter

                //int port = findFreePort();
                //String redirectUri = "http://127.0.0.1:" + port + "/callback";

                int port = 8080;  // fixed port for dev
                String redirectUri = "http://127.0.0.1:8080/callback";


                // ===== Step 2: Build authorize URL =====
                String authorizeUrl = OktaConfig.OKTA_DOMAIN + "/oauth2/v1/authorize?" +
                        "client_id=" + URLEncoder.encode(OktaConfig.CLIENT_ID, "UTF-8") +
                        "&response_type=code" +
                        "&scope=" + URLEncoder.encode(OktaConfig.SCOPE, "UTF-8") +
                        "&redirect_uri=" + URLEncoder.encode(redirectUri, "UTF-8") +
                        "&code_challenge=" + codeChallenge +
                        "&code_challenge_method=S256" +
                        "&state=" + URLEncoder.encode(state, "UTF-8");

                // ===== Step 3: Open browser =====
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().browse(new URI(authorizeUrl));
                } else {
                    callback.onError("Desktop browsing not supported. Open manually:\n" + authorizeUrl);
                    return;
                }

                // ===== Step 4: Start tiny HTTP server =====
                HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
                final String[] authCodeHolder = new String[1];
                final String[] stateHolder = new String[1];

                server.createContext("/callback", exchange -> {
                    String query = exchange.getRequestURI().getQuery();
                    String code = null;
                    String returnedState = null;

                    if (query != null) {
                        for (String param : query.split("&")) {
                            if (param.startsWith("code=")) {
                                code = param.substring(5);
                            } else if (param.startsWith("state=")) {
                                returnedState = param.substring(6);
                            }
                        }
                    }

                    String responseMsg;
                    if (code != null && state.equals(returnedState)) {
                        responseMsg = "Authentication successful! You may close this window.";
                        authCodeHolder[0] = code;
                        stateHolder[0] = returnedState;
                    } else {
                        responseMsg = "Authentication failed. Invalid state or no code received.";
                    }

                    exchange.sendResponseHeaders(200, responseMsg.getBytes().length);
                    OutputStream os = exchange.getResponseBody();
                    os.write(responseMsg.getBytes());
                    os.close();

                    server.stop(0);
                });

                server.start();

                // ===== Step 5: Wait for redirect =====
                while (authCodeHolder[0] == null) {
                    Thread.sleep(500);
                }
                String authorizationCode = authCodeHolder[0];

                // ===== Step 6: Exchange code for tokens =====
                RequestBody tokenBody = new FormBody.Builder()
                        .add("grant_type", "authorization_code")
                        .add("code", authorizationCode)
                        .add("redirect_uri", redirectUri)
                        .add("client_id", OktaConfig.CLIENT_ID)
                        .add("code_verifier", codeVerifier)
                        .build();

                Request tokenRequest = new Request.Builder()
                        .url(OktaConfig.OKTA_DOMAIN + "/oauth2/v1/token")
                        .post(tokenBody)
                        .header("Accept", "application/json")
                        .build();

                Response tokenResponse = client.newCall(tokenRequest).execute();
                String tokenRespStr = tokenResponse.body().string();

                if (!tokenResponse.isSuccessful()) {
                    callback.onError("Token request failed: " + tokenRespStr);
                    return;
                }

                JsonNode tokenJson = mapper.readTree(tokenRespStr);
                String accessToken = tokenJson.get("access_token").asText();
                String idToken = tokenJson.get("id_token").asText();

                callback.onSuccess(accessToken, idToken);

            } catch (Exception e) {
                callback.onError("Exception: " + e.getMessage());
            }
        }).start();
    }

    // ===== Helpers =====
    private static String generateCodeVerifier() {
        byte[] code = new byte[32];
        new SecureRandom().nextBytes(code);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(code);
    }

    private static String generateCodeChallenge(String verifier) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(verifier.getBytes(StandardCharsets.US_ASCII));
        return Base64.getUrlEncoder().withoutPadding().encodeToString(hash);
    }

    private static int findFreePort() throws IOException {
        try (java.net.ServerSocket socket = new java.net.ServerSocket(0)) {
            return socket.getLocalPort();
        }
    }
}
