package org.example.okta;

public class OktaConfig {
    public static final String OKTA_DOMAIN = "https://dev-08094251.okta.com";
    public static final String CLIENT_ID = "0oaq0kywq9A86Thi35d7";
    public static final String SCOPE = "openid profile offline_access";
}
