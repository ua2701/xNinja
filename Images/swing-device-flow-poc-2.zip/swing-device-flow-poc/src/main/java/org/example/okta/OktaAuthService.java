package org.example.okta;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import javax.swing.*;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import java.awt.Dimension;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.Font;
import java.awt.Component;
import java.awt.Color;


public class OktaAuthService {
    private static final OkHttpClient client = new OkHttpClient();
    private static final ObjectMapper mapper = new ObjectMapper();

    public interface AuthCallback {
        void onSuccess(String accessToken, String idToken);
        void onError(String message);
    }

    public static void authenticate(JTextArea outputArea, AuthCallback callback) {
        new Thread(() -> {
            try {
                // Step 1: Request device code
                RequestBody body = new FormBody.Builder()
                        .add("client_id", OktaConfig.CLIENT_ID)
                        .add("scope", OktaConfig.SCOPE)
                        .build();

                Request request = new Request.Builder()
                        .url(OktaConfig.OKTA_DOMAIN + "/oauth2/v1/device/authorize")
                        .post(body)
                        .build();

                Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    callback.onError("Failed to request device code: " + response.code());
                    return;
                }

                JsonNode deviceResponse = mapper.readTree(response.body().string());
                String deviceCode = deviceResponse.get("device_code").asText();
                String userCode = deviceResponse.get("user_code").asText();
                String verificationUri = deviceResponse.get("verification_uri").asText();
                String verificationUriComplete = deviceResponse.get("verification_uri_complete").asText();
                int interval = deviceResponse.get("interval").asInt();

//                JOptionPane.showMessageDialog(null,
//                        "Go to " + verificationUri + "\nEnter Code: " + userCode +
//                        "\nOr open directly: " + verificationUriComplete,
//                        "Okta Authentication", JOptionPane.INFORMATION_MESSAGE);



//                // Create a non-editable but selectable text area
//                JTextArea msgArea = new JTextArea(
//                        "Go to " + verificationUri + "\n\n" +
//                                "Enter Code: " + userCode + "\n\n" +
//                                "Or open directly: " + verificationUriComplete
//                );
//                msgArea.setEditable(false);       // prevent typing
//                msgArea.setOpaque(false);         // blend with dialog background
//                msgArea.setLineWrap(true);
//                msgArea.setWrapStyleWord(true);
//
//// Make text bold and a bit larger
//                msgArea.setFont(new Font("SansSerif", Font.BOLD, 14));
//
//// Give more room so dialog isn't tiny
//                msgArea.setPreferredSize(new Dimension(500, 200));
//
//// Show the message dialog
//                JOptionPane.showMessageDialog(
//                        null,
//                        msgArea,
//                        "Okta Authentication",
//                        JOptionPane.INFORMATION_MESSAGE
//                );

                // Panel with vertical layout
                JPanel panel = new JPanel();
                panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
                panel.setPreferredSize(new Dimension(500, 200));

// Title / instruction
                JLabel lblInstruction = new JLabel("Okta Authentication Required");
                lblInstruction.setFont(new Font("SansSerif", Font.BOLD, 16));
                lblInstruction.setAlignmentX(Component.LEFT_ALIGNMENT);

// Step 1: Verification URI
                JLabel lblStep1 = new JLabel("1. Open this link in your browser:");
                lblStep1.setFont(new Font("SansSerif", Font.PLAIN, 14));
                lblStep1.setAlignmentX(Component.LEFT_ALIGNMENT);

                JTextField uriField = new JTextField(verificationUri);
                uriField.setEditable(false);
                uriField.setFont(new Font("Monospaced", Font.PLAIN, 14));
                uriField.setAlignmentX(Component.LEFT_ALIGNMENT);

// Step 2: User Code
                JLabel lblStep2 = new JLabel("2. Enter the following code:");
                lblStep2.setFont(new Font("SansSerif", Font.PLAIN, 14));
                lblStep2.setAlignmentX(Component.LEFT_ALIGNMENT);

                JTextField codeField = new JTextField(userCode);
                codeField.setEditable(false);
                codeField.setFont(new Font("Monospaced", Font.BOLD, 16));
                codeField.setForeground(Color.RED);
                codeField.setHorizontalAlignment(JTextField.CENTER);
                codeField.setAlignmentX(Component.LEFT_ALIGNMENT);

// Step 3: Direct Link
                JLabel lblStep3 = new JLabel("3. Or open directly:");
                lblStep3.setFont(new Font("SansSerif", Font.PLAIN, 14));
                lblStep3.setAlignmentX(Component.LEFT_ALIGNMENT);

                JTextField directField = new JTextField(verificationUriComplete);
                directField.setEditable(false);
                directField.setFont(new Font("Monospaced", Font.PLAIN, 14));
                directField.setAlignmentX(Component.LEFT_ALIGNMENT);

// Add components to panel
                panel.add(lblInstruction);
                panel.add(Box.createVerticalStrut(10));
                panel.add(lblStep1);
                panel.add(uriField);
                panel.add(Box.createVerticalStrut(10));
                panel.add(lblStep2);
                panel.add(codeField);
                panel.add(Box.createVerticalStrut(10));
                panel.add(lblStep3);
                panel.add(directField);

// Show dialog
                JOptionPane.showMessageDialog(
                        null,
                        panel,
                        "Okta Authentication",
                        JOptionPane.INFORMATION_MESSAGE
                );








                // Step 2: Poll token endpoint
                while (true) {
                    RequestBody tokenBody = new FormBody.Builder()
                            .add("client_id", OktaConfig.CLIENT_ID)
                            .add("device_code", deviceCode)
                            .add("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                            .build();

                    Request tokenRequest = new Request.Builder()
                            .url(OktaConfig.OKTA_DOMAIN + "/oauth2/v1/token")
                            .post(tokenBody)
                            .header("Accept", "application/json")
                            .build();

                    Response tokenResponse = client.newCall(tokenRequest).execute();
                    String tokenRespStr = tokenResponse.body().string();

                    if (tokenResponse.isSuccessful()) {
                        JsonNode tokenJson = mapper.readTree(tokenRespStr);
                        String accessToken = tokenJson.get("access_token").asText();
                        String idToken = tokenJson.get("id_token").asText();
                        callback.onSuccess(accessToken, idToken);
                        break;
                    } else {
                        JsonNode errorResp = mapper.readTree(tokenRespStr);
                        String error = errorResp.has("error") ? errorResp.get("error").asText() : "unknown_error";
                        if ("authorization_pending".equals(error)) {
                            TimeUnit.SECONDS.sleep(interval);
                        } else {
                            callback.onError("Okta Auth Failed: " + error);
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                callback.onError("Exception: " + e.getMessage());
            }
        }).start();
    }
}
