package org.example;
// File: SimpleLoginApp.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.EmptyBorder;

public class SimpleLoginApp extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;

    // Login Page Components
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    // Welcome Page Components
    private JLabel welcomeLabel;
    private JButton logoutButton;

    // Hardcoded credentials
    private static final String USERNAME = "admin";
    private static final String PASSWORD = "password";

    public SimpleLoginApp() {
        // --- Frame Setup ---
        setTitle("Simple Login App");
        setSize(800, 600); // Updated size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window on the screen
        setResizable(false);

        // --- CardLayout Setup for page switching ---
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        // --- Create Panels for each page ---
        JPanel loginPanel = createLoginPage();
        JPanel welcomePanel = createWelcomePage();

        mainPanel.add(loginPanel, "Login");
        mainPanel.add(welcomePanel, "Welcome");

        add(mainPanel);

        // Initially show the login page
        cardLayout.show(mainPanel, "Login");
    }

    private JPanel createLoginPage() {
        // Panel to hold all login components
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 248, 255)); // AliceBlue
        panel.setBorder(new EmptyBorder(50, 50, 50, 50));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Login Title
        JLabel loginTitle = new JLabel("User Login", SwingConstants.CENTER);
        loginTitle.setFont(new Font("Arial", Font.BOLD, 24));
        loginTitle.setForeground(new Color(51, 51, 51));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(loginTitle, gbc);

        // Username
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(usernameLabel, gbc);

        usernameField = new JTextField(15);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 1;
        panel.add(usernameField, gbc);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(passwordLabel, gbc);

        passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 1;
        gbc.gridy = 2;
        panel.add(passwordField, gbc);

        // Login Button
        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(60, 179, 113)); // MediumSeaGreen
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(34, 139, 34), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));



        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        // Action Listener for Login Button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.equals(USERNAME) && password.equals(PASSWORD)) {
                    // Successful login
                    welcomeLabel.setText("Welcome!");
                    cardLayout.show(mainPanel, "Welcome");
                } else {
                    // Failed login
                    JOptionPane.showMessageDialog(SimpleLoginApp.this,
                            "Invalid username or password.",
                            "Login Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        return panel;
    }


    private JPanel createWelcomePage() {
        // Panel with BorderLayout
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(224, 255, 255)); // LightCyan
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // --- Top panel (Welcome + Logout) ---
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false); // transparent background

        // Welcome Label (left side)
        welcomeLabel = new JLabel("Welcome!", SwingConstants.LEFT);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 28));
        welcomeLabel.setForeground(new Color(0, 128, 128)); // Teal
        topPanel.add(welcomeLabel, BorderLayout.WEST);

        // Logout Button (right side)
        logoutButton = new JButton("Logout");
        logoutButton.setFont(new Font("Arial", Font.BOLD, 14));
        logoutButton.setBackground(new Color(255, 99, 71)); // Tomato
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(205, 92, 92), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));

        topPanel.add(logoutButton, BorderLayout.EAST);

        // Add top panel to main panel
        panel.add(topPanel, BorderLayout.NORTH);

        // --- Logout Action Listener ---
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                usernameField.setText("");
                passwordField.setText("");
                cardLayout.show(mainPanel, "Login");
            }
        });

        return panel;
    }


    public static void main(String[] args) {
        // Use the event dispatch thread for GUI applications
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SimpleLoginApp().setVisible(true);
            }
        });
    }
}